#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ALGraph.h"

enum {A,B,C,E,D,F,G,H,I,J,K,L,M,N,O,P,Q};

int main() {

	ALGraph ALG;
	GraphInit(&ALG, 17);

	AddEdge(&ALG, A, B);
	AddEdge(&ALG, C, A);
	AddEdge(&ALG, D, H);
	AddEdge(&ALG, F, G);
	AddEdge(&ALG, B, E);
	AddEdge(&ALG, F, A);
	AddEdge(&ALG, Q, A);
	AddEdge(&ALG, Q, D);
	AddEdge(&ALG, Q, F);

	ShowGraphEdgeInfo(&ALG);

	DFShowGraphPoint(&ALG, Q);
	printf("\n");
		
	return 0;
}