#include <stdlib.h>
#include <stdio.h>
#include "ALGraph.h"
#include "CircularQueue.h"

int WhoIsPrecede(int d1, int d2);

void GraphInit(ALGraph* ALG, int NumOfPoint) {
	ALG->NumOfPoint = NumOfPoint;
	ALG->NumOfLine = 0;
	ALG->Graph = (List*)malloc(sizeof(List) * NumOfPoint);
	ALG->Visit = (int*)malloc(sizeof(int) * NumOfPoint);

	for (int i = 0; i < NumOfPoint; i++) {
		ListInit(ALG->Graph + i);
		ALG->Visit[i] = 0;
		SetSortRule((ALG->Graph + i), WhoIsPrecede);
	}
}
void AddEdge(ALGraph* ALG, int from, int to) {
	LInsert(ALG->Graph + from, to);
	LInsert(ALG->Graph + to, from);

	ALG->NumOfLine += 1;
}
void GraphDelete(ALGraph* ALG) {
	if (ALG->Graph != NULL) {
		free(ALG->Graph);
	}
	if (ALG->Visit != NULL) {
		free(ALG->Visit);
	}
}
void ShowGraphEdgeInfo(ALGraph* ALG) {
	int point;

	for (int i = 0; i < ALG->NumOfPoint; i++) {
		printf("%c�� ����� ������ = ", i + 65);
		
		if (LFirst(ALG->Graph + i, &point)) {
			printf("%c ", point + 65);
			
			while (LNext(ALG->Graph + i, &point)) {
				printf("%c ", point + 65);
			}
		}
		printf("\n");
	}
}

int WhoIsPrecede(int d1, int d2) {
	if (d1 > d2)
		return 1;
	else
		return 0;
}

int VisitPoint(ALGraph* ALG, int visit) {
	if (ALG->Visit[visit] == 0) {
		ALG->Visit[visit] = 1;
		printf("%c ", visit + 65);
		return TRUE;
	}
	return FALSE;
}

void BFShowGraphPoint(ALGraph* ALG, int visit) {
	int next;
	int start = visit;

	Queue queue;
	QueueInit(&queue);
	VisitPoint(ALG, start);
	
	while (LFirst(ALG->Graph + start, &next)) {

		if (VisitPoint(ALG, next)){
			Enqueue(&queue, next);
		}
		while (LNext(ALG->Graph + start, &next)) {
			if (VisitPoint(ALG, next)) {
					Enqueue(&queue, next);
			}
		}

		if(QIsEmpty(&queue))
			break;
		else
			start = Dequeue(&queue);
		
	}
	memset(ALG->Visit,0,sizeof(int)*ALG->NumOfPoint);
}

