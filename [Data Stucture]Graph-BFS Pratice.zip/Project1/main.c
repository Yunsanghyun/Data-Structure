#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ALGraph.h"

enum {A,B,C,D,E,F,G};

int main() {

	ALGraph ALG;
	GraphInit(&ALG, 7);

	AddEdge(&ALG, A, B);
	AddEdge(&ALG, A, D);
	AddEdge(&ALG, B, C);
	AddEdge(&ALG, D, C);
	AddEdge(&ALG, D, E);
	AddEdge(&ALG, E, F);
	AddEdge(&ALG, E, G);

	ShowGraphEdgeInfo(&ALG);

	BFShowGraphPoint(&ALG, A);
	printf("\n");
	BFShowGraphPoint(&ALG, C);
	printf("\n");
	BFShowGraphPoint(&ALG, E);
	printf("\n");
		
	return 0;
}