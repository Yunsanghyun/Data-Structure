#ifndef __TABLE_H__
#define __TABLE_H__

#include "slot.h"
#include "person.h"

#define MAX_LEN 100
	
typedef int (*HashFunction)(key a);

typedef struct Table_list {
	HashFunction func;
	slot arr[MAX_LEN];
}Table;

void TableInit(Table* tbl, HashFunction func);
void TableInsert(Table* tbl, key k, person* p);
person* TableSearch(Table* tbl, key k);
person* TableDelete(Table* tbl, key k);

#endif
