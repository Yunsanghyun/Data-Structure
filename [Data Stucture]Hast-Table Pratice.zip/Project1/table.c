#include <stdio.h>
#include <stdlib.h>
#include "Table.h"

void TableInit(Table* tbl, HashFunction func) {
	for (int i = 0; i < MAX_LEN; i++) {
		tbl->arr[i].status = EMPTY;
	}
	tbl->func = func;
}
void TableInsert(Table* tbl, key k, person* p) {
	int hs_value = tbl->func(k);
	
	tbl->arr[hs_value].status = FULL;
	tbl->arr[hs_value].key_num = k;
	tbl->arr[hs_value].prs = p;
}
person* TableSearch(Table* tbl, key k) {
	int hs_value = tbl->func(k);
	
	if (tbl->arr[hs_value].status != FULL) {
		return NULL;
	}
	else
		return tbl->arr[hs_value].prs;
}
person* TableDelete(Table* tbl, key k) {
	int hs_value = tbl->func(k);

	if (tbl->arr[hs_value].status != FULL) {
		return NULL;
	}
	else {
		tbl->arr[hs_value].status = DELETE;
		return tbl->arr[hs_value].prs;
	}
}

