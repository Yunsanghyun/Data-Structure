#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Table.h"
#include "slot.h"
#include "person.h"

int HashFunc(int a) {
	return a % 10;
}

int main() {
	Table tbl;
	
	person* np1 = MakePerson(1, "������", "���ٸ�");
	person* np2 = MakePerson(2, "�����", "���￪");
	person* np3 = MakePerson(3, "�����", "���￪");
	person* sp;
	person* dp;
	
	TableInit(&tbl, HashFunc);
	TableInsert(&tbl, np1->personal_num, np1);
	TableInsert(&tbl, np2->personal_num, np2);
	TableInsert(&tbl, np3->personal_num, np3);

	sp = TableSearch(&tbl, 1);
	if (sp != NULL) {
		printf("ã����� \n");
		ShowPersonInfo(sp);
	}
	sp = TableSearch(&tbl, 2);
	if (sp != NULL) {
		printf("ã����� \n");
		ShowPersonInfo(sp);
	}
	sp = TableSearch(&tbl, 2);
	if (sp != NULL) {
		printf("ã����� \n");
		ShowPersonInfo(sp);
	}

	dp = TableDelete(&tbl, 1);
	if (sp != NULL) {
		printf("���λ�� \n");
		ShowPersonInfo(dp);
	}
	dp = TableDelete(&tbl, 2);
	if (sp != NULL) {
		printf("���λ�� \n");
		ShowPersonInfo(dp);
	}
	dp = TableDelete(&tbl, 3);
	if (sp != NULL) {
		printf("���λ�� \n");
		ShowPersonInfo(dp);
	}


	return 0;
}