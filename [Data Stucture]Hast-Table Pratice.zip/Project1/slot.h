#ifndef __SLOT_H__
#define __SLOT_H__

#include "person.h"

typedef int key;

enum SlotStatus {EMPTY, DELETE, FULL};

typedef struct person_slot {
	key key_num;
	person* prs;
	enum SlotStatus status;
}slot;

#endif