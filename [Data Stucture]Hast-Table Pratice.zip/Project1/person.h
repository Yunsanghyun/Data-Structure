#ifndef __PERSON_H__
#define __PERSON_H__

#define LEN 50

typedef struct person_info {
	int personal_num; // �ֹι�ȣ
	char name[LEN]; // �̸�
	char address[LEN]; // �ּ�

}person;

int GetPersonalNum(person* p);
void ShowPersonInfo(person* p);
person* MakePerson(int personal_num, char* name, char* address);

#endif