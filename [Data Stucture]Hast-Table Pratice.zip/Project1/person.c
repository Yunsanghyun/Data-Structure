#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "person.h"

int GetPersonalNum(person* p) {
	return p->personal_num;
}

void ShowPersonInfo(person* p) {
	printf("�ֹι�ȣ : %d\n", p->personal_num);
	printf("�̸� : %s\n", p->name);
	printf("�ּ� : %s\n", p->address);
}

person* MakePerson(int personal_num, char* name, char* address) {
	person* new_person = (person*)malloc(sizeof(person));
	new_person->personal_num = personal_num;
	strcpy(new_person->name, name);
	strcpy(new_person->address, address);

	return new_person;
}